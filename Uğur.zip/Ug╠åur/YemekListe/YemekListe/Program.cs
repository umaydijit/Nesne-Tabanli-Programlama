﻿using System;

namespace Yemek_Uygulaması
{
    class yemek
    {
        static void Main(string[] args)
        {
            string ad;
            string yemek_ad;
            string malzeme_isim;

            //  Name
            Console.WriteLine("İsminizi Giriniz :");
            ad = Console.ReadLine();

            // yemek
            Console.WriteLine("Yemeğin Adını Giriniz : ");
            yemek_ad = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("lütfen malzemeleri yazarken araya virgül koyunuz");
            Console.WriteLine();

            // ingredients for food
            Console.WriteLine("Malzeme EKleyiniz");
            malzeme_isim = Console.ReadLine();

            Console.WriteLine("İsminiz: " + ad);
            Console.WriteLine("Yapılacak Yemeğin Adı: " + yemek_ad);
            Console.WriteLine("Yemeğe Konulacak malzemeler: " + malzeme_isim);
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}